


############################################################################################################


# In Week 8, we aim to develop skills in visualizing psychological data


# This week, we focus on using the rich R knowledge ecosystem available online to
# help you to develop more effective data visualizations
# 
# The work we do will enable you to grow in independence during your MSc now
# And this work will enable you to find solutions for yourself in your professional
# working lives afterwards



############################################################################################################


# -- There are three main sources of information you can access for free online:

# -- 1 -- The people who write software like the {tidyverse} or {ggplot2} libraries
# provide manuals, reference guides and tutorials
# -- This information is often written as free web books, or as hard copy books
# 
# -- 2 -- Other people write tutorials or guides or teaching materials designed to
# show learners (like us) how to use R functions or do certain things using R
# -- They may present these tutorials or guides as web books, blog sites or
# video tutorials e.g. on Youtube or TikTok
# 
# -- 3 -- Many post questions and answers to discussion forums like 
# Stackoverflow


# -- Learning how to find, understand and use this information teaches two lessons:
# -- 1 -- A lot of scholarly and technical information is online and free
# -- 2 -- Learning how to access this information is a key way that most professionals
# work out what they want to do and how they can do it  


############################################################################################################


# -- A note about terms --

# -- I will put dataset names in quotes like this: 
#   'study-one-general-participants.csv'
# -- I will put variable (data column) names in quotes like this: 'variable' 
# -- And I will put value or other data object (e.g. cell value) names in quotes like this: 'studyone'

# -- This is to help you distinguish between the ordinary use of words like variable
# from the special use of these words when they are parts of datasets.


# -- A note about coding --

# -- I will structure the code in the practical workbooks in a way that is designed to help you to keep clear 
# what you are doing, even as you increase the power of the plots you produce



############################################################################################################
## Part 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to empty the R environment
rm(list=ls())                            


# -- Task 2 -- Run this code to load relevant libraries
library("ggdist")
library("tidyverse")


# -- You may need to load other libraries as you progress



############################################################################################################
############################################################################################################


# -- In this workbook, we use data from a 2020 study of the response of adults from a UK national
# sample to written health information:

# study-two-general-participants.csv



############################################################################################################
## Part 2: Load data #######################################################################################


# -- Task 3 -- Read in the data file we will be using: 
# study-two-general-participants.csv

# -- We use the read_csv() function to read the data file into R
study.two <- read_csv("study-two-general-participants.csv")  


# -- Task 4 -- Inspect the data file
# -- hint: Task 4 -- Use the summary() or head() functions to take a look
head(study.two)
summary(study.two)



############################################################################################################
## Part 3: Locate and use ggplot2 reference information ####################################################


# -- Task 5 -- Find out how to produce boxplots to examine if vocabulary scores are
# different for people with different education levels

# -- Task 5 -- Specifically, find out how to produce a plot comprising:
# -- 1 -- boxplots showing a summary of vocabulary scores for people with different 
# education levels
# -- 2 -- plus a scatterplot showing individual vocabulary scores for each person
# in the data-set

# -- We can break this task into steps:

# -- 1 -- Find relevant and useful information  
# -- 2 -- Locate example code  
# -- 3 -- Run the example code   
# -- 4 -- Edit the code to do the task with the 'study.two' data


# -- 1 -- Find relevant and useful information

# -- hint: Task 5 -- If you have never created a box plot before, a good place to start
# is the {ggplot2} library reference information


# -- Q.1. -- What keywords can you use to find {ggplot2} library reference information?

# -- Enter your answer here --


# -- Q.2. -- What does a boxplot represent? In other words, what summary
# statistics do the features of a boxplot display?

# -- Enter your answer here --



# -- 2 -- Locate example code

# -- hint: Task 5 -- Most R developers design their information web pages in the same way:
# -- They will give you example code -- in highlighted boxes


# -- Q.3. -- Can you find example code showing how to produce a boxplot that 
# allows you to examine if vocabulary scores are different for people with 
# different education levels?

# -- Enter your answer here --


# -- Q.4. -- Can you find example code showing how to produce a complex plot comprising:
# -- 1 -- boxplots showing a summary of vocabulary scores for people with different 
# education levels
# -- 2 -- plus a scatterplot showing individual vocabulary scores for each person
# in the data-set

# -- Enter your answer here --




# -- Notice:
# -- You will need to understand two things before you move on:

# -- Q.5. -- Can you explain what geom_jitter() does?

# -- Enter your answer here --


# -- Q.6. -- Can you explain what overplotting means?

# -- Enter your answer here --


# -- hint -- If you see a line of code like this:
# p + geom_boxplot(outlier.shape = NA) + geom_jitter(width = 0.2)
# 
# -- You need to pay attention to this bit: p + ...
# 
# -- That means that the code works by:
# -- adding the geom_boxplot() and geom_jitter() layers to a pre-existing plot
# called p

# -- So if you run:
p + geom_boxplot(outlier.shape = NA) + geom_jitter(width = 0.2)
# -- on its own then it will give you an error:
# Error: object 'p' not found

# -- This tells you that you need to define the object 'p' so that R
# can find it
# -- so that R can add the geom_boxplot() and geom_jitter() layers to it

# -- Notice that in the example code in:
# https://ggplot2.tidyverse.org/reference/geom_jitter.html
# -- 'p' is defined first, right at the start of the series of examples

# -- So, what you need to do is build the plot object then add the layers step-by-step


# Look at:
p <- ggplot(data = study.two, aes(x = EDUCATION, y = SHIPLEY))
p + geom_boxplot()
# -- In this sequence of code:
# 
# 1. p <- ggplot(data = mpg, aes(x = class, y = hwy)) 
# -- First constructs a plot object, called 'p'
# -- Nothing will appear in the 'Plots' window but the object 'p' will appear
# in the 'Environment' window in R-Studio
# 
# 2. p + geom_boxplot()  
# -- Adds the object geom_boxplot() to the object 'p'
# -- *This* step is where something is produced in the 'Plots' window
# 
# This style of building a plot step-by-step enables you to construct quite
# complex plots, with multiple layers


# -- 3 and 4 -- Edit the example code to do the task with the 'study.two' data

# -- Q.7. -- Can you edit and run the example code to produce a complex plot comprising:
# -- 1 -- boxplots showing a summary of vocabulary scores for people with different 
# education levels
# -- 2 -- plus a scatterplot showing individual vocabulary scores for each person
# in the data-set

# -- Enter your answer here --


# -- Now look at the plot you have produced and critically evaluate it.


# -- Q.8. -- What does the plot tell you about the average (median)
# vocabulary (SHIPLEY) score recorded for people in the study.two dataset
# who report different education levels?

# -- Enter your answer here --


# -- Q.9. -- What does the plot tell you about the individual i.e. per-person
# vocabulary (SHIPLEY) score recorded for people in the study.two dataset
# who report different education levels?

# -- Enter your answer here --



############################################################################################################
## Part 4: Locate and use tutorial or how-to information ###################################################


# -- Task 6 -- Find out how to construct a rain cloud plot

# -- We break this task into the same steps we followed before:
# -- 1 -- Find relevant and useful information  
# -- 2 -- Locate example code  
# -- 3 -- Run the example code   
# -- 4 -- Edit the code to do the task with the 'study.two' data

# -- hint: Task 6 -- Rain cloud plots are now a popular visualization that incorporates
# elements of the boxplot, the scatterplot and the density plot to give the
# viewer summary information about the distribution of scores on a variable
# and also giving information about the variability of outcomes

# -- hint: Task 6 -- I discuss why this is important in the PSYC403 lecture on
# Perspectives on visualization as well as the PSYC401 lecture on 
# Practices in visualization


# -- 1 -- Find relevant and useful information

# -- hint: Task 6 -- Do a search using the words: how to ggplot rain cloud plot

# -- hint: Task 6 -- That will get you results including these:

# https://www.cedricscherer.com/2021/06/06/visualizing-distributions-with-raincloud-plots-and-how-to-create-them-with-ggplot2/
# -- see also:
# https://z3tt.github.io/Rainclouds/    
#   
# https://www.r-bloggers.com/2021/07/ggdist-make-a-raincloud-plot-to-visualize-distribution-in-ggplot2/  
# -- see also:
# https://rpubs.com/rana2hin/raincloud
#     
# https://wellcomeopenresearch.org/articles/4-63


# -- Q.10. -- There are reasons for doing the things we ask you to learn to do. Can you explain
# briefly why rain cloud plots are useful?
# -- hint: Q.10 -- People often explain why or how to do things in R in general or in visualization
# specifically in academic articles. A good source of information for the answer to this question
# is in the article by Allen et al. in wellcomeopenresearch

# -- Enter your answer here --



# -- 2 -- Locate example code

# -- hint: Task 6 -- Most tutorial or how-to writers design their web pages in the same way:
# -- first, they identify what the question or problem is they are going to
# help you with;
# -- second, they explain what they will do;
# -- third, they may give you example code -- you want this

# -- hint: Task 6 -- You will find some tutorials easier to follow than others
# -- hint: Task 6 -- Pick the one that you can understand most easily


# -- Q.11. -- Example code is often highlighted -- can you see it in the tutorial
# you have chosen to focus on?

# -- Enter your answer here --



# -- 3 -- Run the example code

# -- hint: Task 6 -- A long sequence of code chunks are required to explain
# rain cloud plots, so scroll through whatever tutorial you are looking at
# until you find the bit that is presented e.g. as: Raincloud plots


# -- hint: Task 6 -- Make sure you have copied the *complete* sequence of code
# shown in the highlighted window in the tutorial


# -- 4 -- Edit the code to do the task with the 'study.two' data


# -- Q.12. -- Can you edit the example code to draw a rain cloud plot including
# -- 1 -- boxplots showing a summary of vocabulary scores for people with different 
# education levels
# -- 2 -- plus a scatterplot showing individual vocabulary scores for each person
# in the data-set
# -- hint: Q.12. -- To edit the example code to work for you, you will need to
# change the specification of the dataset and of the 'x = ...' and 'y = ...'
# aesthetic mappings in 'aes(...)'

# -- Enter your answer here --



# -- hint: Task 6 -- Sometimes, when you are working with example code from an online
# source, you need to experiment a bit with the example code to get it to work
# -- hint: Task 6 -- Learning to experiment with codd is a *really* useful skill
# to develop
# -- hint: Task 6 -- You can start by just deleting the arguments inside
# function calls to see what happens
# -- hint: Task 6 -- You will need the example data and aesthetic mappings
# -- hint: Task 6 -- If you delete arguments then you require ggplot() to use
# the defaults
# -- hint: Task 6 -- You can then add arguments in, change their values, to 
# figure out what each argument adds



############################################################################################################
## Part 5: Locate and use Stackoverflow information ########################################################


# -- Task 7 -- Export one of the nice plots you have been making so you can include it in a report

# -- hint: Task 7 -- In the 401-visualization-how-to.R you can find information on how to do this

# -- Adapt the example code to do the task:

# ggplot(iris, aes(Species, Sepal.Width)) + 
#   ggdist::stat_halfeye(adjust = .5, width = .7, .width = 0, justification = -.2, point_colour = NA) + 
#   geom_boxplot(width = .2, outlier.shape = NA) + 
#   geom_jitter(width = .05, alpha = .3)
# 
# ggsave(filename = 'my-plot-2.tiff', device='tiff', dpi=700)

# -- Now you should see:
# -- 1 -- A plot appear in the 'Plots' window in R-Studio  
# -- 2 -- And a plot appear in the 'Files' window in R-Studio

# -- Notice:
# -- I deleted every argument I was not interested in using, e.g. 'width = ...' and 'height = ...'
# -- I gave the file a new name, so that you can see that this works as well as the dev.off() method


# -- Q.13. -- Can you figure out how to insert the plot file you have created into a Word document?
# -- hint: Q.13. -- You can search for information on how to do this by using keywords like: word how to insert an image file

# -- Enter your answer here --


# -- Q.14. -- Can you adapt the colour scheme of the plot to make it look good to you?

# -- Enter your answer here --


# -- Q.15. -- Can you change the theme?  

# -- Enter your answer here --




############################################################################################################


