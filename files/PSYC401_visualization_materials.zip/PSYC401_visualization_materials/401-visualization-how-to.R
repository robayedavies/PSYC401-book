


############################################################################################################


# In Week 8, we aim to develop skills in visualizing psychological data


# This week, we focus on making the most of the rich R knowledge ecosystem available to
# you online
# 
# The work we do will enable you to grow in independence during your MSc now
# And this work will enable you to find solutions for yourself in your professional
# working lives afterwards



############################################################################################################


# -- There are three main sources of information you can access for free online:

# -- 1 -- The people who write software like the {tidyverse} or {ggplot} libraries
# provide manuals, reference guides and tutorials
# -- This information is often written as free web books, or as hard copy books
# 
# -- 2 -- Other people write tutorials or guides or teaching materials designed to
# show learners (like us) how to use R functions or do certain things using R
# -- They may present these tutorials or guides as web books, blog sites or
# video tutorials e.g. on Youtube or TikTok
# 
# -- 3 -- Many post questions and answers to discussion forums like 
# Stackoverflow


# -- Learning how to find, understand and use this information teaches two lessons:
# -- 1 -- A lot of scholarly and technical information is online and free
# -- 2 -- Learning how to access this information is a key way that most professionals
# work out what they want to do and how they can do it  


############################################################################################################


# -- A note about terms --

# -- I will put dataset names in quotes like this: 
#   'study-one-general-participants.csv'
# -- I will put variable (data column) names in quotes like this: 'variable' 
# -- And I will put value or other data object (e.g. cell value) names in quotes like this: 'studyone'

# -- This is to help you distinguish between the ordinary use of words like variable
# from the special use of these words when they are parts of datasets.


# -- A note about coding --

# -- I will structure the code in the practical workbooks in a way that is designed to help you to keep clear 
# what you are doing, even as you increase the power of the plots you produce



############################################################################################################
## Part 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to empty the R environment
rm(list=ls())                            


# -- Task 2 -- Run this code to load relevant libraries
library("tidyverse")


# -- You may need to load other libraries as you progress



############################################################################################################
############################################################################################################


# -- In this how-to guide, we use data from a 2020 study of the response of adults from a UK national
# sample to written health information:

# study-one-general-participants.csv



############################################################################################################
## Part 2: Load data #######################################################################################


# -- Task 3 -- Read in the data file we will be using: 
# study-one-general-participants.csv

# -- We use the read_csv() function to read the data file into R
study.one <- read_csv("study-one-general-participants.csv")  


# -- Task 4 -- Inspect the data file
# -- hint: Task 4 -- Use the summary() or head() functions to take a look
head(study.one)
summary(study.one)



############################################################################################################
## Part 3: Locate and use ggplot2 reference information ####################################################


# -- Task 5 -- Find out how to produce boxplots to examine if vocabulary scores are
# different for people with different education levels

# -- hint: A box plot is a visualization designed to enable you to visualize the
# distribution of scores on a numeric variable, sometimes so that you can
# compare the distribution of scores on that variable in different groups or
# conditions

# -- We can break this task into steps:
# -- 1 -- Find relevant and useful information  
# -- 2 -- Locate example code  
# -- 3 -- Run the example code   
# -- 4 -- Edit the code to do the task with the 'study.one' data

# -- 1 -- Find relevant and useful information

# -- hint: If you have never created a box plot before, a good place to start
# is the {ggplot2} library reference information

# -- hint: Do a search using the words: ggplot reference
# -- hint: That will get you results including this one:
# https://ggplot2.tidyverse.org/reference/  

# -- hint: You know this source is official, relevant, and useful because you can
# see the hex badge: "ggplot2"

# -- hint: We are looking specifically for information on box plots so do a 
# search of the web page e.g. using <CMD-F> (on a Mac) or <CTRL-F> (on a PC) 
# using the words: box or boxplot
# -- hint: That will get you a link -- click on it:
# https://ggplot2.tidyverse.org/reference/geom_boxplot.html

# -- 2 -- Locate example code

# -- hint: Most R developers design their information web pages in the same way:
# -- first, they show a list of arguments you can edit to make choices about
# how functions like geom_boxplot() work;
# -- second, they explain what the object -- here, a boxplot -- represents;
# -- third, they may give you information about what information the function
# can work with;
# -- fourth, they give you example code -- you want this

# -- hint: Example code can be run without reading in any extra data

# -- 3 -- Run the example code

# -- hint: Copy the first bit of example code you see and paste it directly into
# the Console and run it, or paste it into the Script window and run it:

p <- ggplot(mpg, aes(class, hwy))
p + geom_boxplot()

# -- 4 -- Edit the code to do the task with the 'study.one' data

# -- hint: You need to change the data, and the aesthetic mappings -- from this:
  
p <- ggplot(data = mpg, aes(x = class, y = hwy))
p + geom_boxplot()

# -- to this:

p <- ggplot(data = study.one, aes(x = EDUCATION, y = SHIPLEY))
p + geom_boxplot()


# Notice:

# -- 1 -- You can write code quite concisely, i.e.   
# ggplot(mpg, aes(class, hwy))
# -- or more fully:
# ggplot(data = mpg, aes(x = class, y = hwy))  

# -- 2 -- When you construct a boxplot, x must be mapped to a categorical variable
# -- a nominal variable or factor like EDUCATION, ETHNICITY

# -- 3 -- When you construct a boxplot, y must be mapped to a numeric variable
# -- a continuous or interval variable like SHIPLEY


# Notice:
# -- In this sequence of code:
# 
# 1. p <- ggplot(data = mpg, aes(x = class, y = hwy)) 
# -- First constructs a plot object, called 'p'
# -- Nothing will appear in the 'Plots' window but the object 'p' will appear
# in the 'Environment' window in R-Studio
# 
# 2. p + geom_boxplot()  
# -- Adds the object geom_boxplot() to the object 'p'
# -- *This* step is where something is produced in the 'Plots' window
# 
# This style of building a plot step-by-step enables you to construct quite
# complex plots, with multiple layers



############################################################################################################
## Part 4: Locate and use tutorial or how-to information ###################################################


# -- Task 6 -- Find out how to modify the colour of the boxplots to examine if vocabulary scores are
# different for people with different education levels, and to distinguish education by colour

# -- We break this task into the same steps we followed before:
# -- 1 -- Find relevant and useful information  
# -- 2 -- Locate example code  
# -- 3 -- Run the example code   
# -- 4 -- Edit the code to do the task with the 'study.one' data

# -- 1 -- Find relevant and useful information

# -- hint: Do a search using the words: ggplot boxplot colour
# -- hint: That will get you results including this one:
# https://r-graph-gallery.com/264-control-ggplot2-boxplot-colors.html  

# -- hint: This source is not official linked to the {ggplot} project
# so now you have to decide if it is useful
# -- hint: You can decide if a source is useful by trying the example code
# and evaluating if you understand how it works

# -- 2 -- Locate example code

# -- hint: Most tutorial or how-to writers design their web pages in the same way:
# -- first, they identify what the question or problem is they are going to
# help you with;
# -- second, they explain what they will do;
# -- third, they may give you example code -- you want this

# -- hint: Example code is often highlighted -- can you see it?

# -- 3 -- Run the example code

# -- hint: Copy a chunk of example code and paste it directly into
# the Console and run it, or paste it into the Script window and run it:

ggplot(mpg, aes(x=class, y=hwy, fill=class)) + 
  geom_boxplot(alpha=0.3) +
  theme(legend.position="none") +
  scale_fill_brewer(palette="BuPu")

# -- 4 -- Edit the code to do the task with the 'study.one' data

# -- hint: You need to change the data, and the aesthetic mappings -- from this:

ggplot(mpg, aes(x=class, y=hwy, fill=class)) + 
  geom_boxplot(alpha=0.3) +
  theme(legend.position="none") +
  scale_fill_brewer(palette="BuPu")

# -- to this:

ggplot(study.one, aes(x=EDUCATION, y=SHIPLEY, fill=EDUCATION)) + 
  geom_boxplot(alpha=0.3) +
  theme(legend.position="none") +
  scale_fill_brewer(palette="BuPu")


# Notice:

# -- 1 -- You need to make sure that you copy a complete chunk of code
# -- including ggplot()
# -- including aes()
# -- including geom_boxplot()
# -- including scale_fill_brewer()

# -- 2 -- To change the colour of the boxplots, you add:
# fill=EDUCATION -- as an argument to the aesthetic mappings in aes(...)

# -- 3 -- scale_fill_brewer() adds in the colour using the Brewer 
# colour-blind friendly palette


# -- Task 7 -- Can you find out more information about colour palettes?
# -- hint: Do a search using the words: ggplot colour palettes
# -- hint: Do a search using the words: ggplot colour blind friendly palettes
# -- hint: Do a search using the words: ggplot cookbook colour palettes
# -- hint: Results include
# https://ggplot2-book.org/scales-colour
# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/#:~:text=(size%3D3)-,A%20colorblind%2Dfriendly%20palette,variable%2C%20then%20use%20it%20later.


# -- Q. These sources are quite technical in places, can you find useful example code?



############################################################################################################
## Part 5: Locate and use Stackoverflow information ########################################################


# -- Task 7 -- Find out how to export a nice boxplot so you can include it in a report

# -- We break this task into the same steps we followed before:
# -- 1 -- Find relevant and useful information  
# -- 2 -- Locate example code  
# -- 3 -- Run the example code   
# -- 4 -- Edit the code to do the task with the 'study.one' data

# -- hint: In writing a report, we often need to insert an image file

# -- hint: An easy way to do this is to produce your plot in R, save it to an 
# image file, then add the image to your report

# -- hint: The advanced way to do this is to write your report in R:
# https://quarto.org/docs/get-started/hello/rstudio.html  
# -- Then, you can produce the plots and write the texts in the same script.

# -- 1 -- Find relevant and useful information

# -- hint: Do a search using the words: how to export ggplot
# -- hint: That will get you results including this one:

# https://ggplot2.tidyverse.org/reference/ggsave.html
# -- This is the official {ggplot2} library reference information on how to save
# plots

# -- Notice:
# -- This time, the example code at the end of the web page may not be helpful to
# everyone.
# -- The usage information at the beginning tells you what you need to know but you
# will have to look up what arguments like 'device' or 'dpi' mean, and you will
# need to experiment a bit, trying different arguments, to get it to work for you.
# -- Let's move on.

# -- hint: Do a search using the words: how to export ggplot
# -- hint: That will also get you results including this one:
# https://stackoverflow.com/questions/38907514/saving-a-high-resolution-image-in-r

# -- This is what we want: the example code, you will find, is usable and it
# is clearly explained

# -- Notice:
# -- On Stackoverflow, people posts questions and then other people post answers to
# those questions
# -- Still others can up-vote or down-vote the questions and the answers
# -- This system means that the most interesting or useful questions are more
# likely to appear in your search results when you do searches with the right
# key words
# -- In R, someone has usually asked your question before, and someone
# else has usually posted an answer to that question
# -- Here, you can see that the discussion has been viewed 258k times (a lot)
# -- And that many people have up-voted the question and up-voted the answers to
# the question

# -- 2 -- Locate example code 

# -- Notice:
# -- On Stackoverflow, in response to any one question, different people may 
# post alternative answers
# -- Some students may be concerned that there is no one right answer
# -- In mathematics, there are right or wrong answers but this here is something
# different: we are working out how to do something with a computer
# -- The fact that there may be alternative different ways of doing the same
# task is a fair reflection of the reality that with the same set of tools
# different experts can reasonably prefer different approaches or methods

# -- Here, let's just pick the simplest example:
tiff("test.tiff", units="in", width=5, height=5, res=300)
# insert ggplot code
dev.off()

# -- 3 -- Run the example code 

# -- What happens if you run this example code?
tiff("test.tiff", units="in", width=5, height=5, res=300)
# insert ggplot code
dev.off()

# -- hint: Nothing
# -- hint: Notice this bit:

# insert ggplot code

# -- 4 -- Edit the code to do the task with the 'study.one' data

# -- What the authors of the answer are telling you to do is to write *your* bit
# of code to produce a plot where they say: insert ggplot code

# -- Let's do that:

tiff("my-plot.tiff", units="in", width=5, height=5, res=300)

ggplot(study.one, aes(x=EDUCATION, y=SHIPLEY, fill=EDUCATION)) + 
  geom_boxplot(alpha=0.3) +
  theme(legend.position="none") +
  scale_fill_brewer(palette="BuPu")

dev.off()

# -- Notice:
# -- This works but it may appear again as if nothing has happened
# -- But look in R-Studio in the 'Files' window (bottom right screen)
# -- Click on the 'Files' tab
# -- Sort the list of files by date by clicking on the 'Modified' 
# column header
# 
# -- You should see the file: 'my-plot.tiff' in the 'Files' space
# 
# -- You can download this file by ticking the box

# -- Now let's go back to the way that the {ggplot2} library information recommends
# -- Take a look at the second answer to the Stackoverflow question:

ggplot(data=df, aes(x=xvar, y=yvar)) + 
geom_point()

ggsave(path = path, width = width, height = height, device='tiff', dpi=700)

# -- Adapt the example code to do the task:

ggplot(study.one, aes(x=EDUCATION, y=SHIPLEY, fill=EDUCATION)) + 
  geom_boxplot(alpha=0.3) +
  theme(legend.position="none") +
  scale_fill_brewer(palette="BuPu")

ggsave(filename = 'my-plot-2.tiff', device='tiff', dpi=700)

# -- Now you should see:
# -- 1 -- A plot appear in the 'Plots' window in R-Studio  
# -- 2 -- And a plot appear in the 'Files' window in R-Studio

# -- Notice:
# -- I deleted every argument I was not interested in using, e.g. 'width = ...' and 'height = ...'
# -- I gave the file a new name, so that you can see that this works as well as the dev.off() method


# -- Q. Which method do you prefer?



############################################################################################################


