


############################################################################################################


# In Week 10, we aim to *further* develop skills in working with the linear model,
# and in visualizing and testing the associations between variables in psychological 
# data


# We do this to learn how to answer research questions like:

# 1. What person attributes predict success in understanding?
# 2. Can people accurately evaluate whether they correctly understand written health information?

# These kinds of research questions can often be answered through analyses using linear models
# -- We will use linear models to estimate the association between predictors and outcomes


# When we do these analyses, we will need to think about how we report the results:  
# -- we usually need to report information about the kind of model we specify;
# -- and we will need to report the nature of the associations estimated in our model;
# -- we usually need to decide, is the association between the outcome and any one
# predictor significant?
# -- does that association reflect a positive or negative relationship between the
# outcome and that predictor?
# -- are the associations we see in sample data relatively strong or weak?


# We will consolidate and extend learning on data visualization:
# -- Use scatterplots to examine the relationships we may observe or predict
# -- Generate predictions given model estimates of slope coefficients



############################################################################################################
## Part 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to empty the R environment
rm(list=ls())                            


# -- Task 2 -- Run this code to load relevant libraries
library("ggeffects")
library("patchwork")
library("psych")
library("tidyverse")



############################################################################################################
############################################################################################################


# -- In this workbook, we use a collection of data, drawing together data from
# a series of studies, completed by BSc and MSc students, as replications of the
# clearly-understood health comprehension project investigations

# 2022-12-08_all-studies-subject-scores.csv



############################################################################################################
## Part 2: Load data #######################################################################################


# -- consolidation: we use read_csv() again --
# -- introduce: now we add some extra efficiency --


# -- Task 3 -- Read in the data file we will be using: 
# 2022-12-08_all-studies-subject-scores.csv
# -- hint: Task 3 -- Use the read_csv() function to read the data file into R
# -- hint: Task 3 -- Use the col_types = cols() function to tell R how
# to identify nominal variables as factors within the dataset

# -- We use the read_csv() function to read the data file into R

# <-- enter your answer here -->


# -- Task 4 -- Get summary statistics for *only* the numeric variables: AGE, HLVA
# -- hint: Task 4 -- Here, we use the describe() function from the 'psych' library 
# -- hint: Task 4 -- Here, we can do this in two steps: 
# -- 1 -- we select the variables we care about
# -- 2 -- we get just the descriptive statistics we want for those variables

# <-- enter your answer here -->


# -- Q.1. -- What is the mean health literacy (HLVA) score in this sample?

# <-- enter your answer here -->

# -- Q.2. -- What are the minimum and maximum ages in this sample?

# <-- enter your answer here -->

# -- Q.3. -- Do you see any reason to be concerned about the data in this sample?
# -- hint: Q.3. -- It is always a good idea to use your visualization skills to 
# examine the distribution of variable values in a dataset

# <-- enter your answer here -->



############################################################################################################
## Part 3: Use a linear model to to answer the research questions -- one predictor #########################


# -- revision: practice to strengthen skills --


# -- revision: we start by revising how to use lm() with one predictor --


# -- One of our research questions is:
# 2. Can people accurately evaluate whether they correctly understand written 
# health information?


# -- We can address this question by examining whether someone's rated evaluation
# of their own understanding matches their performance on a test of that
# understanding, and by investigating what variables predict variation in 
# mean self-rated accuracy

# -- Note that ratings of accuracy are ordinal data but that, here, we may choose
# to examine the average of participants' ratings of their own understanding of health
# information to keep things fairly simple

# -- For these data, participants were asked to respond to questions about health 
# information to get 'mean.acc' scores and were asked to rate their own understanding 
# of the same information

# -- If you *can* evaluate your own understanding then ratings of understanding *should*
# be associated with performance on tests of understanding


# -- Task 5 -- Estimate the relation between outcome mean self-rated accuracy ('mean.self') 
# and tested accuracy of understanding ('mean.acc')
# -- hint: Task 5 -- For these data, participants were asked to respond to questions
# about health information to get 'mean.acc' scores and were asked to rate their own 
# understanding of the same information

# -- hint: Task 5 -- We can use lm() to estimate whether the ratings of accuracy
# actually predict the outcome tested accuracy levels

# <-- enter your answer here -->

  
# -- If you look at the model summary you can answer the following questions  

# -- Q.1. -- What is the estimate for the coefficient of the effect of the predictor 
# 'mean.self' on the outcome 'mean.acc' in this modelo?

# <-- enter your answer here -->

# -- Q.2. -- Is the effect significant?

# <-- enter your answer here -->

# -- Q.3. -- What are the values for t and p for the significance test for the coefficient?

# <-- enter your answer here -->

# -- Q.4. -- What do you conclude is the answer to the research question, given the 
# linear model results?

# <-- enter your answer here -->

# -- Q.5. -- What is the F-statistic for the regression? Report F, DF and the p-value.

# <-- enter your answer here -->

# -- Q.6. -- Is the regression significant?

# <-- enter your answer here -->

# -- Q.7. -- What is the Adjusted R-squared?

# <-- enter your answer here -->

# -- Q.8. -- Explain in words what this R-squared value indicates?

# <-- enter your answer here -->



############################################################################################################
## Part 5: Use a linear model to to answer the research questions -- multiple predictors ###################


# -- encounter: make some new moves --


# -- One of our research questions is:
# 2. Can people accurately evaluate whether they correctly understand written health information?


# -- We have already looked at this question by asking whether ratings of understanding
# predict performance on tests of understanding
# -- But there is a problem with that analysis -- it leaves open the question: 
# what actually predicts ratings of understanding?

# -- We can look at that follow-up question, next


# -- Task 6 -- Examine the relation between outcome mean self-rated accuracy ('mean.self') 
# and  multiple predictors including:
# health literacy ('HLVA'); vocabulary ('SHIPLEY'); 'AGE'; reading strategy ('FACTOR3');
# as well as 'mean.acc'
# -- hint: Task 6 -- We use lm(), as before, but now specify each variable listed 
# here by variable name

# <-- enter your answer here -->


# -- If you look at the model summary you can answer the following questions  

# -- Q.9. -- What predictors are significant in this model?

# <-- enter your answer here -->

# -- Q.10. -- What is the estimate for the coefficient of the effect of the predictor, 
# 'mean.acc', in this model?

# <-- enter your answer here -->

# -- Q.11. -- Is the effect significant?

# <-- enter your answer here -->

# -- Q.12. -- What are the values for t and p for the significance test for the coefficient?

# <-- enter your answer here -->

# -- Q.13. -- What do you conclude is the answer to the follow-up question, 
# what actually predicts ratings of understanding?

# <-- enter your answer here -->



############################################################################################################
## Part 6: Understanding linear model predictions by comparing one outcome-predictor relation ##############


# Next, we focus in on whether 'mean.self' predicts 'mean.acc' or, in reverse,
# whether 'mean.acc' predicts 'mean.self'?

# -- Note that the comparison between these models teaches us something about 
# *what* linear models predict
  

# -- Q.14. -- Why do you think it appears that the slope coefficient estimate is different
# if you compare :
# (1.) the model, mean.acc ~ mean.self, versus 
# (2.) the model, mean.self ~ mean.acc?
# -- hint: Q.14. -- You want to fit two simple models here, using the verbal description
# in the Q.14 wording

# <-- enter your answer here -->

# -- hint: Q.14. -- You may benefit by reflecting on the lm-intro lecture and
# practical materials, especially where they concern predictions

# <-- enter your answer here -->

# -- Q.15. Can you plot the predictions from each model?

# -- A.15. Here is the code to plot the predictions from both models
# -- hint: A.15. -- First fit the models -- give the model objects distinct names
# -- hint: A.15. -- Then get the predictions
# -- hint: A.15. -- Then make the plots

# <-- enter your answer here -->

# -- Q.16. Look at the two plots side-by-side: what do you see?
# -- hint: Q.16. -- Look at changes in height of the prediction line, given 
# changes in x-axis position of the line

# <-- enter your answer here -->



############################################################################################################
## Part 7: Estimate the effects of factors as well as numeric variables ####################################


# -- consolidate: build your skills --


# -- We have not yet included any categorical or nominal variables as predictors
# but we can, and should: lm() can cope with any kind of variable as a predictor

# -- There are different ways to do this, here we ask you to use the R default method:


# -- Task 11 -- Fit a linear model to examine what variables predict outcome
# mean self-rated accuracy of 'mean.self'
# -- Task 11 -- include in the model both numeric variables and categorical 
# variables as predictors:
# health literacy ('HLVA'); vocabulary ('SHIPLEY'); 'AGE'; reading strategy ('FACTOR3');
# as well as 'mean.acc' and 'NATIVE.LANGUAGE'

# <-- enter your answer here -->


# -- Q.17. -- Can you report the estimated effect of 'NATIVE.LANGUAGE' (the 
# coding of participant language status: 'English' versus 'other')?
# -- hint: Q.17. -- You will need to get a summary of the model

# <-- enter your answer here -->

# -- Q.18. -- Can you report the overall model and model fit statistics?

# <-- enter your answer here -->

# -- Q.18. -- Can you plot the predicted effect of 'NATIVE.LANGUAGE' given your model?
# -- hint: Q.18. -- We first fit the model, including 'NATIVE.LANGUAGE'
# then use the ggpredict() function to get the predictions

# <-- enter your answer here -->

# -- Q.19. -- The plot should give you dot-and-whisker representations of the
# estimated 'mean.self' for 'English' versus 'Other' participants in the dataset.
# What is the difference in the estimated 'mean.self' between these groups?
# -- hint: Q.19. -- The effect or prediction plot will show you dot-and-whisker
# representations of predicted outcome 'mean.self'. In these plots, the dots
# represent the estimated 'mean.self' while the lines (whiskers) represent
# confidence intervals

# <-- enter your answer here -->

# -- Q.20. -- Compare the difference in the estimated 'mean.self' between these groups,
# given the plot, with the coefficient estimate from the model summary: what do you see?

# <-- enter your answer here -->



############################################################################################################
## Part optional: Examine associations comparing data from different samples ###############################


# -- encounter: make some new moves --


# -- The lecture for developing the linear model includes a discussion of the ways
# in which the observed associations between variables or the estimated effects of 
# predictor variables on some outcome may differ between different studies, different
# samples of data


# -- Task optional -- Change the factor in facet_wrap() to show how the association
# between 'mean.self' and 'mean.acc' can vary between the different studies in the
# dataset

# <-- enter your answer here -->


# -- You can read more about faceting here:
#   https://ggplot2.tidyverse.org/reference/facet_wrap.html


# -- Task optional -- You may need to edit the x-axis labeling to make it readable
# -- Can you work out how to do that, given ggplot() help information?
# -- hint: Task optional -- check out the continuous scale information in
# https://ggplot2.tidyverse.org/reference/scale_continuous.html



############################################################################################################
## Part Optional: Save or export plots so that you can insert them in reports ##############################


# -- This is something you have seen -- in the visualization class -- before but it is worth 
# exploring because it may help you later with reports


# -- Task optional -- Save or export a plot that you produce, so that you can insert 
# it in a report or presentation
# -- hint: Task optional -- There are different ways to do this, we can look at 
# one simple example


# -- We can save the last plot we produce using the tidyverse function ggsave():
ggsave("facet-plots.png")
# -- Notice, here, that:
# -- ggsave("facet-plots...") -- we need to give the plot a name
# -- ggsave("...png") -- and we need to tell R what format we require


# -- The plot is saved as a file with the name you specify, in the working directory you are using


# -- R will save the plot in the format you specify: here, I choose .png because 
# .png image files can be imported into Microsoft Word documents easily
# -- Notice that ggsave() will use pretty good defaults but that you can over-ride 
# the defaults, by adding arguments to specify the plot width, height and resolution 
# (in dpi)


# -- Check out reference information here:
# https://ggplot2.tidyverse.org/reference/ggsave.html
# http://www.cookbook-r.com/Graphs/Output_to_a_file/


# -- Now try it for yourself: make a plot, and save it, using what you have 
# learnt so far
# -- Fit a model:
model <- lm(mean.acc ~ HLVA + SHIPLEY + FACTOR3 + AGE, 
            data = all.studies.subjects)
# -- Create a set of predictions we can use for plotting  
dat <- ggpredict(model, "FACTOR3")
# -- make a plot
p.model <- plot(dat)
p.model +
  geom_point(data = all.studies.subjects, 
             aes(x = FACTOR3, y = mean.acc), size = 1.5, alpha = .75, colour = "darkgrey") +
  geom_line(size = 1.5) +
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.15)),
    axis.title = element_text(size = rel(1.25)),
    plot.title = element_text(size = rel(1.4))
  ) +
  xlab("Reading strategy (FACTOR3)") + ylab("Mean accuracy") +
  ggtitle("Effect of reading strategy on \n mean comprehension accuracy")

# -- Save it
ggsave("reading-strategy-prediction.png", width = 10, height = 10, units = "cm")


# -- Some advice:
# -- It is often helpful to present plots that are almost square ie height about = width
# -- This helps to present the best fit line in scatterplots in a way that is easier to perceive
# -- We may experiment with width-height (aspect ratio) until we get something that "looks" right 
# -- Notice also that different presentation venues will require different levels if image
# resolution e.g. journals may require .tiff file plots at dpi = 180 or greater



############################################################################################################

