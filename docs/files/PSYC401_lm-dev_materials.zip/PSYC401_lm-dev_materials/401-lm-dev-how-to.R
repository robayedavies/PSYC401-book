


############################################################################################################


# In Week 10, we aim to *further* develop skills in working with the linear model,
# and in visualizing and testing the associations between variables in psychological 
# data


# We do this to learn how to answer research questions like:

# 1. What person attributes predict success in understanding?
# 2. Can people accurately evaluate whether they correctly understand written health information?

# These kinds of research questions can often be answered through analyses using linear models
# -- We will use linear models to estimate the association between predictors and outcomes


# When we do these analyses, we will need to think about how we report the results:  
# -- we usually need to report information about the kind of model we specify;
# -- and we will need to report the nature of the associations estimated in our model;
# -- we usually need to decide, is the association between the outcome and any one
# predictor significant?
# -- does that association reflect a positive or negative relationship between the
# outcome and that predictor?
# -- are the associations we see in sample data relatively strong or weak?


# We will consolidate and extend learning on data visualization:
# -- Use scatterplots to examine the relationships we may observe or predict
# -- Generate predictions given model estimates of slope coefficients



############################################################################################################


# -- We will take things step-by-step --

# -- I will be explicit about when I will:
# -- introduce -- ask you to do something new;
# -- revise -- where you have started to do things and maybe can use some 
# practice to strengthen skills;
# -- consolidate -- where you have had the chance to practice things before;
# -- extend -- where you can do things that will stretch you -- where you might
# need to do some independent research



############################################################################################################
## Part 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to empty the R environment
rm(list=ls())                            


# -- Task 2 -- Run this code to load relevant libraries
library("ggeffects")
library("patchwork")
library("psych")
library("tidyverse")



############################################################################################################
############################################################################################################


# -- In this how-to guide, we use a collection of data, drawing together data from
# a series of studies, completed by BSc and MSc students, as replications of the
# clearly-understood health comprehension project investigations

# 2022-12-08_all-studies-subject-scores.csv



############################################################################################################
## Part 2: Load data #######################################################################################


# -- consolidation: we use read_csv() again --
# -- introduce: now we add some extra efficiency --


# -- Task 3 -- Read in the data file we will be using: 
# 2022-12-08_all-studies-subject-scores.csv

# -- We use the read.csv() function to read the data file into R
all.studies.subjects <- read_csv("2022-12-08_all-studies-subject-scores.csv", 
                                 col_types = cols(
                                   ResponseId = col_factor(),
                                   study = col_factor(),
                                   EDUCATION = col_factor(),
                                   GENDER = col_factor(),
                                   ETHNICITY = col_factor(),
                                   NATIVE.LANGUAGE = col_factor()
                                 )
                                )

# Notice what we are doing here:
# 1. all.studies.subjects <- read_csv("2022-12-08_all-studies-subject-scores.csv" ..) 
# -- reads in the dataset we name, the .csv
# 2. col_types = cols(
#   ResponseId = col_factor(),
#   ...
# -- tells R how to handle some of the variables in the dataset;
# -- the variables that are listed -- notice: not all of the variables -- are
# categorical or nominal variables that we want R to recognize as factors.
# 3. ))
# -- We embed one function cols() *inside* another function read_csv() and that means
# at the end we need to *close* the brackets

# See here for further information:
# https://robayedavies.github.io/PSYC401-book/visualization.html#sec-vis-ricketts-process-data  


# -- Task 4 -- Inspect the data file
# -- hint: Task 4 -- In previous how-to guides I have advised you to use the summary() 
# or head() functions to look at the data
summary(all.studies.subjects)
# -- hint: Task 4 -- Here, we use the describe() function from the 'psych' library 
describe(all.studies.subjects)


# -- In psychological research reports, we sometimes see table summaries of the 
# predictor or outcome variables in the dataset being analysed
# -- The describe() function in 'psych' is a convenient way to get the descriptive 
# statistics that psychologists commonly report: the mean and standard deviation (SD), 
# minimum (min) and maximum (max)


# -- Task 5 -- Get descriptive statistics for only the variables you want and get 
# only the descriptive statistics you need
# -- We are going to do this in two steps: 
# -- 1 -- we select the variables we care about
# -- 2 -- we get just the descriptive statistics we want for those variables

# -- Task 5 -- First, I am going to do the steps using %>% pipes: 
# -- not everyone likes coding this way so later I'll do it in the old style
all.studies.subjects %>%
  select(mean.acc, mean.self, AGE, SHIPLEY, HLVA, FACTOR3) %>%
  describe(skew = FALSE)

# These are the steps:
# -- 1 -- all.studies.subjects %>% -- you tell R to use the 'all.studies.subjects' dataset, 
# -- then use %>% to ask R to take those data to the next step (ie to %>% pipe it)
# -- 2 -- select(mean.acc, mean.self, AGE, SHIPLEY, HLVA, FACTOR3) %>% 
# -- you tell R to select just those variables in 'all.studies.subjects' you name and pipe %>% 
# them to the next step
# -- 3 -- describe(...) -- you tell R to give you descriptive statistics for the 
# variables you have selected
# -- 4 -- describe(skew = FALSE) -- critically, you add the argument "skew = FALSE" 
# to turn off the option in describe() to report skew, kurtosis 
# -- because we do not typically see these statistics reported in psychology


# -- Task 5 -- Not everyone likes coding this way so now I'll do the same thing in the old style
all.studies.subjects.select <- select(all.studies.subjects, 
                           mean.acc, mean.self, AGE, SHIPLEY, HLVA, FACTOR3)
describe(all.studies.subjects.select, skew = FALSE)

# These are the steps:

# -- 1 -- all.studies.subjects.select <- ...(all.studies.subjects, ...) 
# -- create a new dataset 'all.studies.subjects.select' from the original 
# 'all.studies.subjects'
# -- the new dataset will include just the variables we select from the original

# -- 2 -- select(all.studies.subjects, ...) -- select the variables you want using 
# the select(...) function: telling R to select variables from 'all.studies.subjects'

# -- 3 -- ... select(..., mean.acc, mean.self, AGE, SHIPLEY, HLVA, FACTOR3) 
# -- select the variables you want by entering the variable names, separated by commas, 
# after you have named the dataset

# -- 4 -- describe(...) -- you tell R to give you descriptive statistics

# -- 5 -- describe(all.studies.subjects.select, ...) -- you name the dataset with the 
# selection of variables you have created, telling the describe() function
# what data to work with
# -- 5 -- describe(skew = FALSE) -- critically, you add the argument "skew = FALSE" 
# to turn off the option in describe() to report skew, kurtosis 
# -- We do this because we do not typically see skew statistics reported in psychology


# -- Notice:
# -- we can do exactly the same thing in two different but related ways
# -- use the way that (1.) works and (2.) you prefer
# -- which should you prefer? 
# -- You may reflect on how easy the code is to write, read, understand and use


# -- Here is an explanation for how to use pipes %>% when you code and why it may be helpful to do so:
# https://r4ds.had.co.nz/pipes.html
# -- Note we are not going to require the use of pipes in PSYC401


# -- Notice: 
# -- we modify here how the function describe() works by adding an argument
# describe(skew = FALSE)

# -- We have been doing this kind of move, already, by adding arguments to 
# e.g. specify point colour in ggplot() code

# -- As your skills advance, so your preferences on how you want R to work for you 
# will become more specific
# -- Thus, for example, you can modify the outputs from functions so that you get 
# exactly what you want


# -- The information on the options available to you for any argument can be found 
# in different kinds of places


# -- You can get a guide to the 'psych' library here:
# http://personality-project.org/r/psych/vignettes/intro.pdf  
# -- Every "official" R library has a technical manual on the central R resource CRAN, 
# and the manual for 'psych' can be found here:
# https://cran.r-project.org/web/packages/psych/psych.pdf
# -- where you can see information on the functions the library provides, and how you 
# can use each function

# -- This is the information you see if you ask for help in R for a function e.g.
?describe
# -- or
help(describe)
# -- 'psych' is written by William Revelle who provides a lot of useful resources here:
# http://personality-project.org/r/psych/  



############################################################################################################
## Part 3: Use a linear model to to answer the research questions -- one predictor #########################


# -- revision: practice to strengthen skills --


# -- revision: we start by revising how to use lm() with one predictor --


# -- One of our research questions is:
# 1. What person attributes predict success in understanding?

# -- Task 6 -- Examine the relation between outcome mean accuracy (mean.acc) and 
# health literacy (HLVA)
# -- hint: Task 6 -- We use lm()
model <- lm(mean.acc ~ HLVA, data = all.studies.subjects)
summary(model)

  
# -- If you look at the model summary you can answer the following questions  

# -- Q.1. -- What is the estimate for the coefficient of the effect of the predictor, HLVA?
# -- A.1. -- 0.041188 

# -- Q.2. -- Is the effect significant?
# -- A.2. -- It is significant because p < .05

# -- Q.3. -- What are the values for t and p for the significance test for the coefficient?
# -- A.3. -- t = 12.94, p <2e-16

# -- Q.4. -- What do you conclude is the answer to the research question, given the 
# linear model results?
# -- A.4. -- The model slope estimate suggests that as HLVA scores increase so also 
# do mean.acc scores

# -- Q.5. -- What is the F-statistic for the regression? Report F, DF and the p-value.
# -- A.5. -- F-statistic: 167.5 on 1 and 559 DF,  p-value: < 2.2e-16

# -- Q.6. -- Is the regression significant?
# -- A.6. -- Yes: the regression is significant.

# -- Q.7. -- What is the Adjusted R-squared?
# -- A.7. -- Adjusted R-squared:  0.2292

# -- Q.8. -- Explain in words what this R-squared value indicates?
# -- A.8. -- The R-squared suggests that 23% of outcome variance can be explained 
# by the model


# -- revision: use a linear model to generate predictions --


# -- Task 7 -- We can use the model we have just fitted to plot the model 
# predictions
# -- hint: Task 7 -- We are going to draw a scatterplot and add a line showing 
# the predictions, given the model intercept and effect coefficient estimates

# -- Q.5. -- What is the coefficient estimate for the intercept?
# -- A.5. -- 0.414250

# -- Q.6. -- What is the coefficient estimate for the slope of HLVA?
# -- A.6. -- 0.041188

# -- Use the geom_abline() function to draw the prediction line:
ggplot(data = all.studies.subjects, aes(x = HLVA, y = mean.acc)) +
  geom_point(alpha = 0.5, size = 2,)   +
  geom_abline(intercept = 0.414250, slope = 0.041188, colour = "red", linewidth = 1.5) +
  theme_bw() +
  labs(x = "Health literacy (HLVA)", y = "mean accuracy") +
  xlim(0, 16) + ylim(0, 1)
  
# -- You can see that all we do is:
# -- add the geom_abline(...) function
# -- and in that, add information about the intercept and the slope

# -- See reference information here:  
#   https://ggplot2.tidyverse.org/reference/geom_abline.html      



############################################################################################################
## Part 4: Use a linear model to to answer the research questions -- multiple predictors ###################


# -- encounter: make some new moves --


# -- One of our research questions is:
# 1. What person attributes predict success in understanding?

# -- Task 8 -- Examine the relation between outcome mean accuracy (mean.acc) and 
# multiple predictors including:
# health literacy (HLVA); vocabulary (SHIPLEY); AGE; reading strategy (FACTOR3)
# -- hint: Task 8 -- We use lm(), as before, but now specify each variable listed 
# here by variable name
model <- lm(mean.acc ~ HLVA + SHIPLEY + FACTOR3 + AGE, data = all.studies.subjects)
summary(model)


# -- Notice that we do the linear model in the steps:

# -- 1 -- model <- lm(...) -- fit the model using lm(...), give the model a name 
# -- here, we call it "model"

# -- 2 -- ...lm(mean.acc ~ HLVA...) 
# -- tell R you want a model of the outcome 'mean.acc' 
# -- predicted (~) by the predictors:
# 'HLVA', 'SHIPLEY', 'FACTOR3', 'AGE'

# -- Note that we use the variable names as they appear in the dataset, and that 
# each predictor variable is separated from the next by a plus sign

# -- 3 -- ...data = all.studies.subjects) -- tell R that the variables you name 
# in the formula live in the 'all.studies.subjects' dataset

# -- 4 -- summary(model) -- ask R for a summary of the model you called "model"


# -- Notice: R has a general formula syntax: outcome ~ predictor *or* y ~ x
# -- and uses the same format across a number of different functions
# -- each time, the left of the tilde symbol ~ is some output or outcome
# -- and the right of the tilde ~ is some input or predictor or set of predictors


# -- If you look at the model summary you can answer the following questions  

# -- Q.7. -- What is the estimate for the coefficient of the effect of the predictor, 
# 'HLVA', in *this* model?
# -- A.7. -- 0.0274954 

# -- Q.8. -- Is the effect significant?
# -- A.8. -- It is significant because p < .05

# -- Q.9. -- What are the values for t and p for the significance test for the coefficient?
# -- A.9. -- t = 8.470, p < 2e-16

# -- Q.10. -- What do you conclude is the answer to the research question, 
# given the linear model results?
# -- A.10. -- The model slope estimate 0.0274954 suggests that as HLVA scores 
# increase so also do mean.acc scores

# -- Q.11. -- How is the coefficient estimate for the HLVA slope similar or different, 
# comparing this model with multiple predictors to the previous model with one predictor?
# -- A.11. -- It can be seen that the HLVA estimate in the two models is different 
# in that it is a bit smaller in the model with multiple predictors compared to the 
# model with one predictor 
# -- The HLVA estimate is similar in that it remains positive, it is about the 
# same size


# -- Notice that:-

# -- The estimate of the coefficient of any one predictor can be expected to 
# vary depending on the presence of other predictors.
# -- This is one reason why we need to be transparent about why we choose to use 
# the predictors we include in our model.
# -- The lecture for week 10 discusses this concern in relation to the motivation 
# for good open science practices.

  
# -- Q.12. -- Can you report the estimated effect of SHIPLEY (the measure of vocabulary)?
# -- A.12. -- The effect of vocabulary knowledge (SHIPLEY) on mean accuracy of 
# understanding is significant (estimate = 0.01, t = 7.30, p < .001)
# indicating that increasing skill is associated with increasing accuracy

# -- Q.13. -- Can you report the model and the model fit statistics?
# -- A.13. -- We fitted a linear model with mean comprehension accuracy as the 
# outcome and health literacy (HLVA),  reading strategy (FACTOR3), vocabulary (SHIPLEY) 
# and AGE (years) as predictors.
# The model is significant overall, with F(4, 556) = 85.17, p < .001, and 
# explains 38% of variance (adjusted R2 = 0.38).



############################################################################################################
## Part 5: Plot predictions from linear models with multiple predictors ####################################


# -- encounter: make some new moves --


# -- Task 9 -- Plot linear model predictions for one of the predictors
# -- hint: Task 9 -- Previously, we used geom_abline(), specifying intercept and 
# slope estimates, to draw model predictions
# -- Here, we use functions that are very helpful when we need to plot model 
# predictions for a predictor, for models where we have multiple predictors, and 
# we have to take into account the influence on outcomes of the other predictors
  

# -- We do this in three steps:
# -- 1 -- We first fit a linear model of the outcome, given our predictors
# -- We save information about the model
# -- 2 -- We use the ggpredict() function from the 'ggeffects' library to take  
# the information about the model and create a set of predictions we can use for plotting
# -- 3 -- We plot the model predictions (marginal effects plots)


# -- These steps proceed as follows:-


# -- 1 -- We first fit a linear model of the outcome, given our predictors
model <- lm(mean.acc ~ HLVA + SHIPLEY + FACTOR3 + AGE, data = all.studies.subjects)
# -- 1.1 -- model <- lm(...) -- we fit the model using lm(...), give the model a name 
# -- here, we call it "model"
# -- 1.2 -- ...lm(mean.acc ~ HLVA...) 
# -- tell R you want a model of the outcome 'mean.acc' predicted (~) by
# the predictors 'HLVA', 'SHIPLEY', 'FACTOR3', 'AGE'

# -- Notice: when we use lm() to fit the model, R creates a set of information 
# about the model, including estimates
# -- We give that set of information a name, and we use that name, next, to 
# access the model information

# -- 2 -- We use the ggpredict() function from the 'ggeffects' library to take  
# the information about the model and create a set of predictions we can use for 
# plotting  
dat <- ggpredict(model, "HLVA")

# -- Notice:
# -- 2.1 -- dat <- ggpredict(...) -- We ask R to create a set of predictions, 
# and we give that set of predictions a name 'dat'
# -- 2.2 -- ... ggpredict(model, "HLVA") -- We tell R what model information 
# it should use (from 'model'), and which predictor variable we need predictions for 'HLVA'

# -- 3 -- We plot the model predictions (marginal effects plots)
plot(dat)


# -- Task 10 -- Edit the appearance of the marginal effect (prediction) plot as 
# you can with any ggplot object
p.model <- plot(dat)
p.model +
  geom_point(data = all.studies.subjects, 
             aes(x = HLVA, y = mean.acc), size = 1.5, alpha = .75, colour = "lightgreen") +
  geom_line(size = 1.5) +
  ylim(0, 1.1) + xlim(0, 16) +
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.15)),
    axis.title = element_text(size = rel(1.25)),
    plot.title = element_text(size = rel(1.4))
  ) +
  xlab("Health literacy (HLVA)") + ylab("Mean accuracy") +
  ggtitle("Effect of health literacy on mean comprehension accuracy")

# -- Notice that we do this in stages, as we have done for other kinds of plots:

# -- 1 -- p.model <- plot(dat) -- we create a plot object, which we call 'p.model'

# -- 2 -- p.model + 
# -- we then set up the first line of a series of code lines, starting with the name of 
# the plot, 'p.model' and a + to show we are going to add some edits

# -- 3 -- geom_point(data = all.studies.subjects, aes(x = HLVA, y = mean.acc) ...) 
# -- we first add the raw data points showing the observed HLVA and mean.acc for 
# each person in our sample

# -- 4 -- geom_point(... size = 1.5, alpha = .75, colour = "lightgreen") + 
# -- we modify the appearance of the points, then

# -- 5 -- geom_line(size = 1.5) + 
# -- we add the prediction line, using the predictions created earlier, then

# -- 6 -- ylim(0, 1.1) + xlim(0, 16) + 
# -- we set axis limits to show the full potential range of variation in each variable, then

# -- 7 -- theme_bw() -- we set the theme to black and white, then

# -- 8 -- theme(axis.text = element_text(size = rel(1.15)), 
#               axis.title = element_text(size = rel(1.25)), 
#               plot.title = element_text(size = rel(1.4))
#               )
# -- we modify the relative size of x-axis, y-axis and plot title label font, then

# -- 9 -- xlab("Health literacy (HLVA)") + ylab("Mean accuracy") + 
# -- we edit labels to make them easier to understand, then

# -- 10 -- ggtitle("Effect of health literacy on mean comprehension accuracy") 
# -- we give the plot a title


# -- Notice that here, we are constructing a complex plot from two datasets:
# -- We use plot(dat) to construct a plot showing the prediction line using
# geom_line(size = 1.5) +  
# -- We then add a layer to the plot to show the raw sample data, using
# geom_point(data = all.studies.subjects, 
#            aes(x = HLVA, y = mean.acc) ...)
# -- to tell R to work with the sample data-set 'all.studies.subjects'
# -- and to show points representing the (aesthetic mappings) values,
# given that sample data, for (x = HLVA, y = mean.acc)
  
# -- This complex plot is a good example of:
# -- 1 -- How we can plot summary of prediction data plus observed outcomes, and 
# this connects to the week 8 PSYC401 and PSYC403 classes on visualization
# -- 2 -- How we can add layers or objects together to create sophisticated
# plots that can show our audience messages like, here, that there is an
# average trend (shown by the line) but that individual outcomes vary quite a bit


# -- Task 11 -- Now produce plots that show the predictions for all the predictor 
# variables in the model
# -- hint: Task 11 -- You can create a set of plots then put them together in a 
# grid for presentation

# -- 1 -- The code may get pretty lengthy
# -- 2 -- Adjust axis labels so for each plot we see the correct predictor as the x-axis label
# -- 3 -- In each plot, first plot the original sample observations as points *then* the prediction line
# -- 4 -- Give the plot titles as letters a-e so that, if you put this plot in a report, you can refer
# to each plot by letter in comments



############################################################################################################
## Part 6: Estimate the effects of factors as well as numeric variables ####################################


# -- consolidate: build your skills --


# -- We have not yet included any categorical or nominal variables as predictors
# but we can, and should: lm() can cope with any kind of variable as a predictor

# -- There are different ways to do this, here we look at two


# -- Task 11 -- Fit a linear model including both numeric variables and categorical 
# variables as predictors
# -- hint: Task 11 -- We can inspect the data to check what variables are
# categorical or nominal variables -- factors -- using summary()
summary(all.studies.subjects)
# -- R shows factors with a count of the number of observations for each level
# -- hint: Task 11 -- Include the factor NATIVE.LANGUAGE as a predictor
model <- lm(mean.acc ~ HLVA + SHIPLEY + FACTOR3 + AGE + NATIVE.LANGUAGE, 
            data = all.studies.subjects)


# -- Q.14. -- Can you report the estimated effect of NATIVE.LANGUAGE (the 
# coding of participant language status: English versus other)?
# -- hint: Q.14. -- You will need to get a summary of the model
summary(model)
# -- A.14. -- The effect of language status (NATIVE.LANGUAGE) on mean accuracy of 
# understanding is significant (estimate = -0.09, t = -6.37, p < .001)
# indicating that not being a native speaker of English ('Other') is associated 
# with lower accuracy

# -- Q.15. -- Can you report the model and the model fit statistics?
# -- A.15. -- We fitted a linear model with mean comprehension accuracy as the 
# outcome and health literacy (HLVA),  reading strategy (FACTOR3), vocabulary (SHIPLEY) 
# and AGE (years), as well as language status as predictors.
# The model is significant overall, with F(5, 555) = 81.09, p < .001, and 
# explains 42% of variance (adjusted R2 = 0.42).

# -- Q.16. -- What changes, when you compare the models with versus without NATIVE.LANGUAGE?
# -- A.16. -- If you compare the summaries, for the last two models, you can see that
# the proportion of variance explained, R-sq, increases to 42% (0.4221), suggesting that
# knowing about participant language background helps to account for their response
# accuracy in tests of comprehension of health advice.

  
# -- R handles factors, by default, by picking one level ('English') as the reference level
# (or baseline) and comparing outcomes to that baseline, for each other factor level
# (here, 'Other')
# -- Thus, in this model, the effect of 'NATIVE.LANGUAGE' is estimated as the difference
# in 'mean.acc' outcome for 'English' compared to 'Other' participants
# -- This is why the effect is listed as:
# NATIVE.LANGUAGEOther  
# -- in the model summary


# -- There are different ways to code factors for analysis
# -- If you are doing an analysis where your data come from e.g. a factorial
# design (e.g. a 2 x 2 study design) then you will want to use a different coding
# scheme: e.g. sum or effect coding
# -- It is easy to do this, in two steps


# -- These steps proceed as follows:-
  
# -- 1 -- We first change the coding scheme

# -- 1.1 -- get the memisc library
library(memisc)
# -- 1.2 -- check the coding
contrasts(all.studies.subjects$NATIVE.LANGUAGE)
# -- 1.3 -- change it
contrasts(all.studies.subjects$NATIVE.LANGUAGE) <- contr.sum(2, base = 1)
# -- 1.4 -- check the coding to show you got what you want
contrasts(all.studies.subjects$NATIVE.LANGUAGE)

# -- warning --
# -- Loading the memisc library can cause problems when using dplyr (tidyverse) 
# functions like select: the problem is expressed as e.g. select() not being
# able to see variables listed for selection
# -- You can fix this problem by restarting R or by requiring R to use
# dplyr::select()
# -- I would normally avoid problems like this but the memisc contr.sum()
# function is too useful to ignore

# -- Notice:
# -- 1.1 -- We use the memisc library because it provides some functions that are
# convenient to use
# -- 1.2 -- contrasts(all.studies.subjects$NATIVE.LANGUAGE) -- shows us the R default
# -- called dummy coding:
# Other
# English     0
# Other       1  
# -- 1.3 -- contrasts(all.studies.subjects$NATIVE.LANGUAGE) <- contr.sum(2, base = 1)
# -- we use the contr.sum() function to tell R how many levels there are for the
# factor (2: 'NATIVE.LANGUAGE' is coded as 'Other' or 'English')
# -- and we use contr.sum() function to tell R which level we want to be the reference
# level

# -- 2 -- We then fit a linear model of the outcome, given our predictors
model <- lm(mean.acc ~ HLVA + SHIPLEY + FACTOR3 + AGE + NATIVE.LANGUAGE, 
            data = all.studies.subjects)
summary(model)
# -- 2.1 -- model <- lm(...) -- we fit the model using lm(...), give the model a name 
# -- here, we call it "model"
# -- 2.2 -- ...lm(mean.acc ~ HLVA...) 
# -- tell R you want a model of the outcome 'mean.acc' predicted (~) by the predictors 
# 'HLVA', 'SHIPLEY', 'FACTOR3', 'AGE', 'NATIVE.LANGUAGE'
# -- 2.2 -- summary(model) -- we then get a model summary


# -- Q.17. -- What changes, when you compare the models with versus without sum coding
# of NATIVE.LANGUAGE?
# -- A.17. -- If you compare the summaries, for the last two models, you can see that
# the estimate for the coefficient of 'NATIVE.LANGUAGE' changes in two ways:
# -- the name changes, from NATIVE.LANGUAGEOther to NATIVE.LANGUAGE2, reflecting the
# change in coding;
# -- the slope estimate changes, from -0.0900035 to -0.0450018

# -- Note: the change in the estimate happens because we go from estimating the 
# average difference in level between 0 ('English') versus 1 ('Other'), a change of one
# unit to estimating the average difference in level between -1 ('English') versus 1
# ('Other'), a change of 2 units


# -- Being able to change the coding of nominal or categorical variables is very useful
# -- And enables you to do ANOVA style analyses given factorial study designs e.g.
model <- aov(lm(mean.acc ~ HLVA + SHIPLEY + FACTOR3 + AGE + NATIVE.LANGUAGE, 
       data = all.studies.subjects))
summary(model)

# -- Notice: we use aov() to get an ANOVA summary


# -- Task 12 -- Fit a linear model including both numeric variables and categorical 
# variables as predictors: and then plot the predicted effect of the factor
# -- hint: Task 12 -- We first fit the model, including NATIVE.LANGUAGE
# then use the ggpredict() function to get the predictions

dat <- ggpredict(model, "NATIVE.LANGUAGE")
plot(dat)


# -- You can read more about factor coding schemes here:
# https://talklab.psy.gla.ac.uk/tvw/catpred/
# https://phillipalday.com/stats/coding.html  



############################################################################################################
## Part optional: Work out how to recode factor levels #####################################################


# -- introduce: work out how to do something new --


# -- Factors -- categorical or nominal variables -- are a special kind of variable in R
# and there is a library of functions, forcats, you can familiarise yourself with, if
# you are going to be working with factors


# -- Here, we look at a common task, recoding the levels of a factor

# -- You might want to do this e.g. if you are worried about imbalances in factor
# level numbers


# -- Task optional -- Change the ways that the levels of a factor are coded


# -- Consider the factor EDUCATION in the all.studies.subjects dataset
# -- Task optional -- Can you find out how many observations there are, of participants 
# at each level of (self-reported) education?
# -- hint: Task optional -- You can use summary() for this
summary(all.studies.subjects$EDUCATION)

# > summary(all.studies.subjects$EDUCATION)
# Further Secondary    Higher 
# 229        66       320 


# What if we think that it does not make much sense to distinguish between Further and
# Secondary?

# -- Task optional -- Change Further and Secondary to School in the way that EDUCATION responses
# are coded

all.studies.subjects <- all.studies.subjects %>%
  mutate(education = fct_recode(EDUCATION,
                                
                                'School' = 'Further',
                                'School' = 'Secondary'
                                
                                ))

# -- We work through the steps:
# -- 1 -- all.studies.subjects <- all.studies.subjects %>%
# -- create a new dataset from the old dataset
# -- 2 -- mutate(education = fct_recode(EDUCATION
# -- create a new variable, using mutate()
# -- I call the new variable 'education'
# -- create the new variable by recoding the old variable 'EDUCATION'
# -- use the function fct_recode() to do the recoding
# -- 3 -- *inside* fct_recode() you specify how you want the recoding to work:
# 'School' = 'Further',
# 'School' = 'Secondary' 
# -- note 'School' = 'Further' means: new level name = old level name

# -- Inspect what we get:
summary(all.studies.subjects$EDUCATION)  
summary(all.studies.subjects$education)  
# -- Notice in the new 'education' both 'Further' and 'Secondary' are now classed as 
# 'School'


# -- Q.optional -- How do you recode ETHNICITY? Maybe we think need to recode ETHNICITY
# so that we use the simplified scheme: White versus BAME
# -- A.optional -- Like this:
all.studies.subjects <- all.studies.subjects %>%
  mutate(ethnicity = fct_recode(ETHNICITY,
                                
                                'BAME' = 'Asian',
                                'BAME' = 'Black',
                                'BAME' = 'Mixed',
                                'BAME' = 'Other'
                                
                                ))

# -- Inspect what we get:
summary(all.studies.subjects$ETHNICITY)  
summary(all.studies.subjects$ethnicity)  


# Note that the ethnic category 'BAME' will be present in the literature but is no
# longer recommended, see e.g.
# https://www.ethnicity-facts-figures.service.gov.uk/style-guide/writing-about-ethnicity



############################################################################################################
## Part optional: Examine associations comparing data from different samples ###############################


# -- encounter: make some new moves --


# -- The lecture for developing the linear model includes a discussion of the ways
# in which the observed associations between variables or the estimated effects of 
# predictor variables on some outcome may differ between different studies, different
# samples of data

# -- To draw the plots, I used facet_wrap:

all.studies.subjects %>%
  ggplot(aes(x = SHIPLEY, y = mean.acc)) +
  geom_point(size = 2, alpha = .5, colour = "darkgrey") +
  geom_smooth(size = 1.5, colour = "red", method = "lm", se = FALSE) +
  xlim(0, 40) +
  ylim(0, 1.1)+
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.15)),
    axis.title = element_text(size = rel(1.5))
  ) +
  xlab("Vocabulary (Shipley)") + ylab("Mean accuracy") +
  facet_wrap(~ study)

# -- What is new here is this bit:
# facet_wrap(~ study) 

# -- This is how it works:
# -- 1 -- facet_wrap() -- the function asks R to take the dataset and split it
# into subsets
# -- 2 -- facet_wrap(~ study) -- tells the function to split the dataset
# according to the different levels of a named factor: 'study'

# -- So: you need identify a factor variable to do this


# -- Task optional -- Change the factor in facet_wrap() to show how the vocabulary
# effect may vary between English monolinguals versus non-native speakers of English
all.studies.subjects %>%
  ggplot(aes(x = SHIPLEY, y = mean.acc)) +
  geom_point(size = 2, alpha = .5, colour = "darkgrey") +
  geom_smooth(size = 1.5, colour = "red", method = "lm", se = FALSE) +
  xlim(0, 40) +
  ylim(0, 1.1)+
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.15)),
    axis.title = element_text(size = rel(1.5))
  ) +
  xlab("Vocabulary (Shipley)") + ylab("Mean accuracy") +
  facet_wrap(~ NATIVE.LANGUAGE)


# -- You can read more about faceting here:
#   https://ggplot2.tidyverse.org/reference/facet_wrap.html



############################################################################################################


